#include <iostream>

using namespace std;

int main() {
    int n;
    int a[100][100];
    for (int i = 0; i < 100; ++i) {
        for (int j = 0; j < 100; ++j) {
            a[i][j] = 0;
        }
    }

    cin >> n;
    int x1, y1, x2, y2;
    for (int i = 0; i < n; ++i) {
        cin >> x1 >> y1 >> x2 >> y2;
        for (int i = x1; i < x2; ++i) {
            for (int j = y1; j < y2; ++j) {
                a[i][j] = 1;
            }
        }
    }
    int sum=0;
    for (int i = 0; i < 100; ++i) {
        for (int j = 0; j < 100; ++j) {
            if(a[i][j]!=0){
                ++sum;
            }
        }
    }
    cout<<sum<<endl;
    return 0;
}