#include <iostream>

using namespace std;

int main() {
    int n;
    cin >> n;
    int value;
    int a[1000];
    for (int i = 0; i < 1000; ++i) {
        a[i] = 0;
    }
    for (int i = 0; i < n; ++i) {
        cin >> value;
        ++a[value];
    }

    int max = 0;
    int tag;
    while (n--) {
        for (int i = 0; i < 1000; ++i) {
            if (a[i] > max) {
                max = a[i];
                tag = i;
            }
        }
        if (max == 0)
            break;
        cout << tag << " " << max << endl;
        a[tag] = 0;
        max = 0;
    }
    return 0;
}