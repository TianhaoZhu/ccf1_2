#include <iostream>
#include <map>
using namespace std;
int main() {
    int n;
    cin>>n;
    int value;
    map<int ,int> my_map;
    for(int i=0;i<n;++i){
        cin>>value;
        cout<<++my_map[value]<<" ";
    }

    return 0;
}