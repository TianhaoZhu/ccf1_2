#include <iostream>

using namespace std;

int main() {
    int m, n;
    cin >> m >> n;
    int a[m][n];
    int b[m][n];
    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) {
            cin >> a[i][j];
            b[i][j] = a[i][j];
        }
    }
    //消除列
    for (int i = 0; i < m - 2; ++i) {
        for (int j = 0; j < n; ++j) {
            if (a[i][j] == a[i + 1][j]&&a[i][j] == a[i + 2][j]) {
                b[i][j] = b[i + 1][j] = b[i + 2][j] = 0;
            }
        }
    }
    //消除行
    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n - 2; ++j) {
            if (a[i][j] == a[i][j + 1]&&a[i][j] == a[i][j + 2]) {
                b[i][j] = b[i][j + 1] = b[i][j + 2] = 0;
            }
        }
    }
    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) {
            cout<<b[i][j]<<" ";
        }
        cout<<endl;
    }
    return 0;
}