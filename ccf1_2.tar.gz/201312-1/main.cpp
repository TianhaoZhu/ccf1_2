#include <iostream>
#include <map>

using namespace std;

int main() {
    map<int, int> my_Map;
    int n;
    cin >> n;
    int value;
    for (int i = 0; i < n; ++i) {
        cin >> value;
        ++my_Map[value];
    }

    int max = 0;
    int maxnum = 10000;
    map<int, int>::iterator it = my_Map.begin();
    while (it != my_Map.end()) {
        if (it->second > max) {
            max = it->second;
            maxnum = it->first;
        }
        else if (it->second = max) {
            if (it->first < maxnum) {
                max = it->second;
                maxnum = it->first;
            }
        }
        ++it;
    }
    cout << maxnum << endl;
    return 0;
}