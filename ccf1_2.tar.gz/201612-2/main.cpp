#include <iostream>

using namespace std;

int main() {
    int n, p;
    int a[10];
    cin >> n;
    for (int i = 0; i < 10; ++i) {
        a[i] = 5;
    }
    while (n--) {
        cin >> p;
        for (int i = 0; i < 10; ++i) {
            if (p <= a[i]) {
                for (int j = 5 - a[i]; j <5 - a[i]+ p; ++j) {
                    cout << i * 5 + j + 1 << " ";
                }
                cout << endl;
                a[i] -= p;
                break;
            }
        }
    }
    return 0;
}