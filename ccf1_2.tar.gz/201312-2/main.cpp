#include <iostream>
using namespace std;
int main() {
    string s;
    int si;
    int sum=0;
    int cs=1;
    cin>>s;
    for(int i=0;i<s.length()-2;++i){
        if(s[i]>='0'&&s[i]<='9'){
            si=s[i]-'0';
            sum+=si*cs;
            cs++;
        }
    }
    if(sum%11==s[s.length()-1]){
        cout<<"Right"<<endl;
    } else{
        s[s.length()-1]=sum%11+'0';
        cout<<s<<endl;
    }
    return 0;
}