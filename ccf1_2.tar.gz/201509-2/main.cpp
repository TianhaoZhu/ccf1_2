#include <iostream>

using namespace std;

int main() {
    int y, d;
    cin >> y >> d;
    int a[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    int ar[12] = {31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0) {
        int m = 0;
        while (d - ar[m] > 0) {
            d -= ar[m];
            m++;
        }
        cout << m + 1 << endl << d;
    } else {
        int m = 0;
        while (d - a[m] > 0) {
            d -= a[m];
            m++;
        }
        cout << m + 1 << endl << d;
    }
    return 0;
}